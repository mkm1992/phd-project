from services.obtainNet.main_service import MainService

class ObtainService:
	@classmethod
	def check_url(cls, content_type):
		print(content_type, "the content tope")


	
	def obtain_process(url):
		content_type= url
		return ObtainService.check_url(content_type)


        
