ROUTE=r"/cover_rug"
